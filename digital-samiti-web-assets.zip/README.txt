# Digital Samiti Web Brand Assets

## Included files
- `digital-samiti-logo.png` / `.webp`: complete vertical logo for login, about and marketing sections.
- `digital-samiti-horizontal.png` / `.webp`: horizontal lockup for website header/navbar.
- `digital-samiti-icon.png` / `.webp`: emblem-only square app icon.
- `favicon.ico` and `favicon-*.png`: browser favicon sizes.
- `apple-touch-icon.png`: iOS home-screen icon.
- `android-chrome-*.png`: Android/PWA icons.
- `site.webmanifest`: basic PWA manifest.

## Suggested usage
- Navbar: `digital-samiti-horizontal.webp`
- Login / landing page: `digital-samiti-logo.webp`
- Small UI icon: `digital-samiti-icon.webp`
- Browser tab: `favicon.ico`

The artwork uses a deep navy and gold visual theme. Keep sufficient contrast and clear space around the logo.
