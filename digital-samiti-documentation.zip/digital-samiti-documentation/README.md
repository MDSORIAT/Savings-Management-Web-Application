# Digital Samiti

Digital Samiti is a web application concept for managing group savings and member contributions.

> **Important:** This repository is a project plan and starter documentation, not proof that a financial product is legally approved or production-ready. Before handling real money, obtain qualified legal, compliance, tax, and payment-provider advice for every target country, including Japan.

## Documentation map

- `AI_INSTRUCTIONS.md` — mandatory instructions for AI coding agents.
- `docs/ai-tracking/` — project context, tasks, decisions, session and issue tracking.
- `docs/project/` — product scope, pages, user journeys and requirements.
- `docs/technical/` — architecture, database, API and deployment.
- `docs/security/` — security and financial-data controls.
- `docs/design/` — brand, typography, colors and UI rules.
- `frontend/` and `backend/` — create these when implementation begins.

## Suggested technology direction

- Frontend: React, JavaScript, React Router
- Backend: Node.js, Express
- Database: MongoDB with Mongoose
- Authentication: secure password hashing and short-lived access tokens; choose a secure refresh-token strategy
- Hosting: GitHub for source control, Railway or another suitable host for services, MongoDB Atlas or another managed database
- Uploads: private object storage; do not rely on an ephemeral application filesystem

Versions must be selected and pinned when the project is initialized. Check compatibility and security advisories at that time.

## Getting started

1. Read `AI_INSTRUCTIONS.md`.
2. Read `docs/ai-tracking/PROJECT_MASTER.md` and `TASK_TRACKER.md`.
3. Review `docs/project/PROJECT_FEATURES.md`.
4. Agree on legal/compliance scope before enabling any real-money feature.
5. Initialize the repository and record actual versions and decisions.
