# AI Agent Instructions — Digital Samiti

## Mandatory startup sequence

Before editing code, read these files in order:

1. `README.md`
2. `docs/ai-tracking/PROJECT_MASTER.md`
3. `docs/ai-tracking/TASK_TRACKER.md`
4. `docs/ai-tracking/DEVELOPMENT_ROADMAP.md`
5. `docs/ai-tracking/AI_CONTEXT.md`
6. `docs/ai-tracking/RULES.md`
7. `docs/ai-tracking/DECISIONS.md`
8. Relevant product, technical and security documents.

Then inspect the actual repository: source files, package manifests, Git status, recent commits, environment examples, and tests. Documentation may be stale; code and verified behavior are evidence. Report discrepancies before making risky changes.

## Working rules

- Work on one main task at a time.
- Choose the next task from `TASK_TRACKER.md`; do not repeat completed work without a reason.
- Preserve the approved architecture and existing conventions.
- Do not silently change frameworks, database design, API contracts, folder structure, or business rules.
- Ask for approval before destructive changes, major scope changes, or changes to financial workflows.
- Do not invent completed features, test results, legal approval, payment confirmation, or deployment status.
- Never commit secrets, credentials, private keys, real customer data, or payment evidence.
- Validate all untrusted input on the server.
- Enforce authorization on the server, not only in the UI.
- Keep financial records auditable. Do not silently overwrite verified transactions.
- Opening a banking app or showing transfer instructions is not payment confirmation.
- Treat lottery, pooled funds, custody, lending, and payout mechanics as compliance-sensitive. Do not enable real-money operations until the owner confirms qualified legal/compliance review.

## Task status definitions

- `NOT_STARTED`: not begun.
- `IN_PROGRESS`: active work.
- `BLOCKED`: cannot proceed; blocker must be recorded.
- `REVIEW`: implementation awaits review.
- `TESTING`: verification is underway.
- `COMPLETED`: implementation and required verification are complete.

Only use `COMPLETED` when the acceptance criteria are met and test evidence is recorded.

## Required end-of-session updates

Update applicable files:
- `TASK_TRACKER.md`
- `AI_CONTEXT.md`
- `SESSION_LOG.md`
- `CHANGELOG.md` (create at repository root when implementation changes)
- `BUG_TRACKER.md`
- `TEST_REPORT.md`
- `DECISIONS.md` for approved architectural/product decisions

Do not erase earlier session history. Add a dated entry.

## End-of-session report

Provide:
1. Summary
2. Tasks completed and status
3. Files created/modified
4. Commands and tests run, with actual results
5. Known bugs and blockers
6. Security or compliance concerns
7. Next recommended task

## Source-of-truth rule

- Actual source code and executed tests show what is implemented.
- `DECISIONS.md` records approved decisions and rationale.
- `TASK_TRACKER.md` records work status.
- `AI_CONTEXT.md` is a concise handoff snapshot.
- Never claim a planned feature is already implemented.
