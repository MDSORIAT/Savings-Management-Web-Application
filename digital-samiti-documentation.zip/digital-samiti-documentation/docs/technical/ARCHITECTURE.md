# Technical Architecture

## High-level flow

Browser / React frontend → HTTPS API → Express backend → MongoDB.

Private files should be stored in a dedicated object-storage service. The database stores object keys and metadata, not public permanent URLs for sensitive evidence.

## Frontend responsibilities
- Render pages and forms.
- Client-side input feedback for usability.
- Route guards for user experience only.
- API requests and response handling.
- Never treat frontend checks as authorization.

## Backend responsibilities
- Authentication and authorization.
- Server-side validation.
- Business rules and status transitions.
- Database access.
- Audit logging.
- Rate limiting and security headers.
- Payment-provider integration only after provider approval.

## Suggested source layout

```text
frontend/
  src/
    assets/
    components/
    layouts/
    pages/
      public/
      auth/
      member/
      group-admin/
      super-admin/
    routes/
    services/
    hooks/
    context/
    utils/
    styles/

backend/
  src/
    config/
    models/
    controllers/
    routes/
    middleware/
    services/
    validators/
    utils/
    jobs/
    app.js
    server.js

docs/
```

## Environment configuration

Use `.env.example` with placeholder values. Keep real credentials in local ignored `.env` files or a secret manager.

Examples of variable names:
- `NODE_ENV`
- `PORT`
- `MONGODB_URI`
- `JWT_ACCESS_SECRET` (if this token design is selected)
- `FRONTEND_ORIGIN`
- `STORAGE_BUCKET`
- `STORAGE_ACCESS_KEY`

Do not place secrets in source code, documentation, screenshots, or logs.
