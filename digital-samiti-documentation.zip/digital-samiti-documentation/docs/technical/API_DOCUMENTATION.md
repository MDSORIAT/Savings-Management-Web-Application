# API Documentation — Proposed Contract

Prefix: `/api/v1`

All routes and schemas below are proposals. Confirm exact payloads and status codes during implementation.

## Authentication
- `POST /auth/register`
- `POST /auth/login`
- `POST /auth/logout`
- `POST /auth/refresh` (only if refresh-token design is adopted)
- `POST /auth/forgot-password`
- `POST /auth/reset-password`

## Users
- `GET /users/me`
- `PATCH /users/me`

## Groups
- `POST /groups`
- `GET /groups`
- `GET /groups/:groupId`
- `PATCH /groups/:groupId`
- `POST /groups/:groupId/invitations`
- `POST /groups/:groupId/join`

## Contributions
- `GET /groups/:groupId/contributions`
- `POST /groups/:groupId/contributions` (authorized admin/system action)
- `GET /contributions/:contributionId`
- `POST /contributions/:contributionId/payment-evidence`
- `POST /payments/:paymentId/review` (authorized reviewer only)

## Admin and support
- `GET /admin/users`
- `GET /admin/groups`
- `GET /admin/audit-logs`
- `POST /support/tickets`

## API standards
- Validate path, query and body inputs.
- Return consistent error objects without stack traces.
- Authenticate protected endpoints.
- Authorize access to the specific group/resource.
- Apply pagination and safe filtering to list endpoints.
- Rate-limit login, password reset and sensitive actions.
- Never trust a user-supplied `userId`, role, payment status or amount without server-side checks.
