# Deployment Documentation

## Proposed deployment layout
- GitHub: source repository and pull requests.
- Frontend: static hosting or a suitable web service.
- Backend: Railway or another managed application host.
- Database: MongoDB Atlas or a reviewed managed MongoDB provider.
- Uploads: private object storage.

These are proposed services, not yet confirmed or deployed.

## Deployment checklist
- [ ] Select hosting region based on latency, data residency and legal requirements.
- [ ] Pin and verify runtime/package versions.
- [ ] Create separate development, staging and production environments.
- [ ] Configure secrets in the hosting provider dashboard.
- [ ] Configure database network access and least-privilege credentials.
- [ ] Configure allowed frontend origins and HTTPS.
- [ ] Configure health checks, logs and monitoring.
- [ ] Configure backups and test restoration.
- [ ] Configure private object storage and access policy.
- [ ] Run migrations/index setup and smoke tests.
- [ ] Review rollback procedure.
- [ ] Complete legal, privacy and security launch gates.

## Important
Do not store uploaded receipts on an ephemeral app filesystem. Do not commit `.env` files. Do not deploy real-money functionality before required approvals.
