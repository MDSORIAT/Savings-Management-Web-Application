# Architecture and Product Decisions

Record approved decisions with date, owner, context, alternatives and consequences. Proposed choices are not final until confirmed.

## D-001 — Proposed frontend
- Status: PROPOSED
- Choice: React with JavaScript.
- Reason: Component-based UI and broad ecosystem.
- Revisit: If team skill or project constraints change.

## D-002 — Proposed backend
- Status: PROPOSED
- Choice: Node.js with Express.
- Reason: JavaScript across frontend and backend.

## D-003 — Proposed database
- Status: PROPOSED
- Choice: MongoDB with Mongoose.
- Reason: Document-oriented data model.
- Note: Validate transaction and consistency requirements before finalizing.

## D-004 — Payment state
- Status: APPROVED PRODUCT RULE
- Choice: Opening a bank app never marks a contribution as paid.
- Reason: App launch is not settlement evidence.

## D-005 — Real-money and lottery features
- Status: BLOCKED PENDING REVIEW
- Choice: Do not enable until qualified legal/compliance review is documented.
