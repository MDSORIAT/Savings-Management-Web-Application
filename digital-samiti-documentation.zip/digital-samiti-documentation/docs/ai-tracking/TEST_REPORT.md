# Test Report

No application tests have been run as part of this documentation pack.

For each test run, record:

## Test run — YYYY-MM-DD
- Commit:
- Environment:
- Command:
- Scope:
- Result: NOT_RUN / PASSED / FAILED
- Failed tests:
- Known limitations:
- Tester:

Never report `PASSED` unless the command was executed and the result checked.
