# AI Context — Current Handoff

**Project:** Digital Samiti  
**Snapshot date:** 2026-11-02  
**Current phase:** Planning / documentation  
**Implementation status:** Not verified. Do not assume the application has been built.

## Known direction
- Premium formal fintech-inspired design.
- Brand palette: navy, gold, white and light gray.
- Proposed stack: React, Node.js/Express, MongoDB/Mongoose.
- GitHub for source control.
- Railway and MongoDB Atlas are options, not confirmed production choices.
- Japan is a target-market consideration; regulatory review is required.

## Critical product rules
- Opening a bank app does not confirm payment.
- Payment status must be verified separately.
- Do not enable pooled funds, real-money payouts or lottery/random selection until qualified legal/compliance review is complete.

## Next action
Confirm product scope, jurisdiction, and legal/compliance constraints. Then inspect the repository and update this file with verified implementation facts.

## Handoff checklist
- [ ] Read AI_INSTRUCTIONS.md.
- [ ] Inspect Git status and source tree.
- [ ] Verify package versions and services.
- [ ] Compare implementation against TASK_TRACKER.md.
- [ ] Update this snapshot after work.
