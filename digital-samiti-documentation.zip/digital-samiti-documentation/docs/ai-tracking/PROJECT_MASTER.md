# Project Master — Digital Samiti

## Project identity

**Name:** Digital Samiti  
**Type:** Responsive web application concept for group savings administration  
**Brand direction:** Premium, formal, trustworthy fintech-inspired interface  
**Initial market assumption:** Japan-oriented planning; legal and payment requirements must be confirmed.

## Problem

Informal savings groups often coordinate members, contribution dates, payment records, and payouts through chat messages and spreadsheets. Digital Samiti aims to organize these activities with clear records and role-based access.

## Intended users

- Visitor: views public information.
- Member: joins a group, views obligations and records, submits payment evidence where enabled.
- Group administrator: manages group membership and reviews records.
- Platform administrator: manages platform-level users, groups, support, and audit oversight.

## Core product areas

1. Account registration and authentication.
2. User profile and dashboard.
3. Group creation, invitations and membership.
4. Contribution schedule and ledger.
5. Payment evidence and verification workflow.
6. Payout schedule and payout records, subject to legal approval.
7. Notifications and support.
8. Platform administration and audit history.

## Proposed stack

- Frontend: React + JavaScript; React Router.
- Backend: Node.js + Express.
- Database: MongoDB + Mongoose.
- Validation: server-side schema validation.
- Authentication: secure password hashing and carefully designed token/session handling.
- Source control: Git and GitHub.
- Hosting: Railway or a reviewed alternative; managed MongoDB service.
- File storage: private object storage for sensitive uploads.

Exact package versions, hosting regions, and service choices must be recorded in `DECISIONS.md` after verification.

## Non-goals until separately approved

- Acting as a bank or payment institution.
- Holding customer funds.
- Guaranteeing returns or savings outcomes.
- Automatically moving money without an authorized provider.
- Operating a lottery or random payout scheme without legal review.
- Treating a bank-app launch, screenshot, or user statement as verified settlement.

## Product principles

- Clear status and transparent records.
- Least-privilege access.
- Accessible, responsive UI.
- Financial actions must be traceable.
- No misleading claims about safety, returns, or legal status.
