# Task Tracker

**Rule:** Initial statuses below are `NOT_STARTED` unless verified otherwise in the repository.

## Phase 0 — Product and compliance
- [ ] Confirm operating jurisdiction and user eligibility — `NOT_STARTED`
- [ ] Confirm whether platform ever holds or transfers funds — `NOT_STARTED`
- [ ] Legal review of savings, pooled funds, payout and lottery-like mechanics — `NOT_STARTED`
- [ ] Approve MVP requirements — `NOT_STARTED`

## Phase 1 — Foundation
- [ ] Create GitHub repository — `NOT_STARTED`
- [ ] Initialize React frontend — `NOT_STARTED`
- [ ] Initialize Express backend — `NOT_STARTED`
- [ ] Add linting, formatting and test setup — `NOT_STARTED`
- [ ] Configure environment variables — `NOT_STARTED`

## Phase 2 — Design system
- [ ] Add brand tokens and typography — `NOT_STARTED`
- [ ] Build responsive app shell — `NOT_STARTED`
- [ ] Build reusable form, card, table and status components — `NOT_STARTED`
- [ ] Accessibility review — `NOT_STARTED`

## Phase 3 — Authentication
- [ ] Registration and login — `NOT_STARTED`
- [ ] Password reset — `NOT_STARTED`
- [ ] Session/token handling — `NOT_STARTED`
- [ ] Role and group authorization — `NOT_STARTED`

## Phase 4 — Groups
- [ ] Group CRUD — `NOT_STARTED`
- [ ] Invitations and membership — `NOT_STARTED`
- [ ] Group schedule and rules — `NOT_STARTED`

## Phase 5 — Contributions
- [ ] Contribution ledger — `NOT_STARTED`
- [ ] Member contribution history — `NOT_STARTED`
- [ ] Admin review workflow — `NOT_STARTED`
- [ ] Audit events — `NOT_STARTED`

## Phase 6 — Payments
- [ ] Confirm authorized payment model — `NOT_STARTED`
- [ ] Implement payment provider or manual review — `NOT_STARTED`
- [ ] Duplicate/reconciliation controls — `NOT_STARTED`

## Phase 7 — Payouts and reporting
- [ ] Obtain required approval — `NOT_STARTED`
- [ ] Implement approved payout workflow — `NOT_STARTED`
- [ ] Reports and exports — `NOT_STARTED`

## Phase 8 — Launch readiness
- [ ] Security and privacy review — `NOT_STARTED`
- [ ] Automated test coverage — `NOT_STARTED`
- [ ] Backup and restore test — `NOT_STARTED`
- [ ] Deployment and monitoring — `NOT_STARTED`

**Current next task:** Complete Phase 0 discovery and confirm the legal/product model before implementing real-money functionality.
