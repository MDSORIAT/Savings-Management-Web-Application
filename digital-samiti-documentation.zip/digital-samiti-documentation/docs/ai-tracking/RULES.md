# Project Rules

1. Follow approved architecture and naming conventions.
2. Do not change major technology choices without approval.
3. Do not delete important files or data without explicit authorization.
4. Do not duplicate existing features; inspect before creating.
5. Keep secrets in environment variables or an approved secret manager.
6. Commit `.env.example`, never real `.env` secrets.
7. Validate and authorize on the server.
8. Use least-privilege database and hosting credentials.
9. Keep financial history auditable and correction events traceable.
10. Do not mark payments paid based on a bank-app launch or screenshot alone.
11. Do not enable regulated financial/lottery features before required review.
12. Add tests for important business logic and security boundaries.
13. Update docs and task status after implementation.
14. Do not mark untested tasks complete.
15. Use clear, descriptive Git commits and review changes before merging.
