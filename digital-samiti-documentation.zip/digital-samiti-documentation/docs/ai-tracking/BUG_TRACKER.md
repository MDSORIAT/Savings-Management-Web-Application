# Bug Tracker

No implementation bugs have been verified yet because the application repository has not been inspected.

Use this template for each issue:

## BUG-XXX — Short title
- Status: OPEN
- Priority: LOW / MEDIUM / HIGH / CRITICAL
- Environment:
- Steps to reproduce:
- Expected result:
- Actual result:
- Evidence/logs (remove secrets and personal data):
- Assigned to:
- Fix:
- Regression test:
