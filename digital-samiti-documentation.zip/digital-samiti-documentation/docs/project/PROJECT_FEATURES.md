# Product Features and Requirements

## MVP features

### Public
- Landing page explaining the service accurately.
- About, contact, terms, privacy and help pages.
- Clear eligibility and risk disclosures.

### Authentication
- Registration and login.
- Email/phone verification according to selected provider and jurisdiction.
- Password reset.
- Session management and logout.
- Server-side role checks.

### Member
- Profile and account settings.
- Dashboard showing joined groups and upcoming contributions.
- Group details and member list (subject to privacy permissions).
- Contribution history and current status.
- Notifications.

### Group administrator
- Create and edit group details.
- Invite, approve, suspend or remove members according to group rules.
- Define contribution amount and schedule.
- Review submitted payment evidence.
- Maintain a record of approved corrections.
- View group reports.

### Platform administrator
- User and group oversight.
- Support ticket management.
- Audit-log review.
- Abuse reports and account restrictions.
- Configuration with strong access controls.

## Payment workflow requirements

1. Show the amount, recipient details and reference clearly.
2. A `Send Money` action may open a bank app only where an official supported link exists.
3. If no supported link exists, show bank-transfer instructions and a copyable reference.
4. App launch does not prove that a transfer occurred.
5. Payment starts as `PENDING` or `PROOF_SUBMITTED`.
6. Verification must use an approved provider integration or a documented authorized review process.
7. Only authorized server-side logic can set `VERIFIED` / `PAID`.
8. Store reviewer, timestamp, evidence reference and transaction reference.
9. Corrections must create an audit event; do not silently overwrite history.

## Payout workflow

Payout features remain disabled until the business model and applicable law have been reviewed. If approved, document eligibility, schedule, authorization, settlement evidence, reversals, disputes, and audit requirements before implementation.

## Acceptance criteria

- Each feature has a written user story and acceptance criteria.
- Every protected API checks authorization server-side.
- Loading, empty, success and error states are present.
- Important flows have automated or documented manual tests.
- User-facing financial statuses are accurate and unambiguous.
