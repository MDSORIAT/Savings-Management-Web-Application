# Database Documentation — Proposed Model

This is a starting design. Review transaction consistency, retention, privacy, and legal requirements before implementation.

## Proposed collections

### users
- `_id`
- `name`
- `email` / `phone` (unique where applicable)
- `passwordHash`
- `platformRole`
- `status`
- `createdAt`, `updatedAt`

### groups
- `_id`
- `name`
- `description`
- `createdBy`
- `currency`
- `contributionAmount`
- `contributionFrequency`
- `status`
- `createdAt`, `updatedAt`

### groupMembers
- `_id`
- `groupId`
- `userId`
- `groupRole`
- `membershipStatus`
- `joinedAt`

### invitations
- `_id`
- `groupId`
- `invitedBy`
- `recipient`
- `tokenHash`
- `expiresAt`
- `status`

### contributions
- `_id`
- `groupId`
- `memberId`
- `period`
- `amount`
- `currency`
- `status`
- `dueAt`
- `createdAt`, `updatedAt`

### payments
- `_id`
- `contributionId`
- `provider`
- `providerReference`
- `evidenceObjectKey`
- `status`
- `verifiedBy`
- `verifiedAt`
- `createdAt`, `updatedAt`

### payouts (only if legally approved)
- `_id`
- `groupId`
- `recipientId`
- `amount`
- `currency`
- `status`
- `authorizedBy`
- `settledAt`
- `createdAt`, `updatedAt`

### auditLogs
- `_id`
- `actorId`
- `action`
- `resourceType`
- `resourceId`
- `metadata` (avoid secrets and unnecessary personal data)
- `createdAt`

### notifications and supportTickets
Store only the minimum required data and define retention/access rules.

## Data integrity rules

- Add indexes for common queries and unique constraints where required.
- Use MongoDB transactions when multiple related writes must succeed or fail together and the deployment supports them.
- Prevent duplicate payment references and duplicate contribution creation.
- Store currency explicitly; never assume all amounts use the same currency.
- Store timestamps consistently in UTC and display in the user's selected timezone.
- Do not store raw card data, bank credentials, or online banking passwords.
- Define retention, deletion, export, and backup policies.
