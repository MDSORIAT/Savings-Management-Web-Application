# Page and Navigation Documentation

## Public pages
- `/` — landing page.
- `/about` — service explanation.
- `/how-it-works` — plain-language process.
- `/terms` — terms, reviewed by qualified counsel.
- `/privacy` — privacy notice, reviewed for target jurisdictions.
- `/contact` — contact/support entry point.

## Authentication pages
- `/register`
- `/login`
- `/forgot-password`
- `/reset-password`

## Member pages (authentication required)
- `/dashboard`
- `/profile`
- `/groups`
- `/groups/:groupId`
- `/contributions`
- `/contributions/:contributionId`
- `/notifications`
- `/settings`

## Group-admin pages (group-level permission required)
- `/manage/groups/:groupId`
- `/manage/groups/:groupId/members`
- `/manage/groups/:groupId/contributions`
- `/manage/groups/:groupId/payment-review`
- `/manage/groups/:groupId/reports`

## Platform-admin pages (platform role required)
- `/admin`
- `/admin/users`
- `/admin/groups`
- `/admin/support`
- `/admin/audit-logs`

## UI requirements

- Responsive layouts for mobile, tablet and desktop.
- Accessible labels, keyboard navigation and visible focus states.
- Confirm destructive actions.
- Show permission errors without leaking private information.
- Never show another group's private data to an unauthorized user.
- Financial pages must show currency, amount, period, status and reference clearly.
