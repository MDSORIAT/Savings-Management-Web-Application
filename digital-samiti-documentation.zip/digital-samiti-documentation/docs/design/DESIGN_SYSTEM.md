# Digital Samiti — Design System

## Brand direction
Premium, formal, calm and trustworthy. Use navy as the structural brand color and gold as a restrained accent. Avoid excessive gradients, shiny effects, or gold text on white when contrast is insufficient.

## Color tokens

| Token | Hex | Use |
|---|---|---|
| Primary Navy | `#071A35` | Sidebar, primary actions, headings |
| Navy Light | `#102C50` | Hover and secondary surfaces |
| Gold | `#D6A84F` | Brand accent and important highlights |
| Gold Light | `#F1D58F` | Dark-surface accent |
| Background | `#F4F6FA` | App background |
| Surface | `#FFFFFF` | Cards and forms |
| Text Primary | `#172B4D` | Main text |
| Text Secondary | `#66758A` | Supporting text |
| Border | `#E5EAF1` | Dividers and inputs |
| Success | `#16A36A` | Verified/success state |
| Warning | `#D99A24` | Pending state |
| Danger | `#DC4545` | Error state |
| Info | `#2878D0` | Informational state |

## Typography
- English: Inter.
- Bangla: Noto Sans Bengali.
- Use readable sizes and line heights.
- Do not rely on color alone to communicate status.

## Components
- Buttons: navy primary, gold accent, outline secondary.
- Cards: white surface, subtle border and shadow, 12–18px radius.
- Inputs: clear labels, visible focus ring and validation message.
- Tables: clear headings, responsive overflow and readable row spacing.
- Status badges: success, pending, failed and informational states.
- Navigation: navy sidebar and clean white top bar.

## Layout
- Mobile-first responsive behavior.
- Consistent spacing scale.
- Visible keyboard focus.
- Accessible contrast and touch target sizes.
- Include loading, empty, error and success states.

## Logo usage
- Horizontal logo: navbar.
- Full logo: landing/login/marketing.
- Emblem: app icon and compact spaces.
- Maintain clear space; do not stretch or recolor the logo without approval.
