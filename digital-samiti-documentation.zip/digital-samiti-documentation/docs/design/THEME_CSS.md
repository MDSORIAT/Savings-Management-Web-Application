# Theme CSS

Copy this into `frontend/src/styles/theme.css` after the frontend is initialized.

```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+Bengali:wght@400;500;600;700;800&display=swap');

:root {
  --primary: #071A35;
  --primary-light: #102C50;
  --primary-hover: #163B66;
  --gold: #D6A84F;
  --gold-light: #F1D58F;
  --gold-dark: #B88932;
  --background: #F4F6FA;
  --surface: #FFFFFF;
  --surface-soft: #F8FAFD;
  --text-primary: #172B4D;
  --text-secondary: #66758A;
  --text-muted: #94A3B8;
  --success: #16A36A;
  --success-bg: #E8F7EF;
  --danger: #DC4545;
  --danger-bg: #FDECEC;
  --warning: #D99A24;
  --warning-bg: #FFF5DE;
  --info: #2878D0;
  --info-bg: #EAF3FF;
  --border: #E5EAF1;
  --shadow-sm: 0 2px 8px rgba(7,26,53,.05);
  --shadow-md: 0 8px 24px rgba(7,26,53,.08);
  --radius-sm: 8px;
  --radius-md: 12px;
  --radius-lg: 18px;
  --radius-xl: 24px;
  --font-en: 'Inter', sans-serif;
  --font-bn: 'Noto Sans Bengali', sans-serif;
}

* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: var(--font-en), var(--font-bn);
  background: var(--background);
  color: var(--text-primary);
  line-height: 1.6;
}
button, input, select, textarea { font: inherit; }
.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
  padding: 24px;
}
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 11px 20px;
  border: 0;
  border-radius: var(--radius-md);
  font-weight: 600;
  cursor: pointer;
}
.btn-primary { background: var(--primary); color: white; }
.btn-primary:hover { background: var(--primary-hover); }
.btn-gold { background: var(--gold); color: var(--primary); }
.form-control {
  width: 100%;
  padding: 12px 14px;
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  background: white;
  color: var(--text-primary);
}
.form-control:focus {
  outline: 2px solid var(--gold);
  outline-offset: 2px;
}
.sidebar { background: var(--primary); color: white; min-height: 100vh; }
.navbar { background: white; border-bottom: 1px solid var(--border); }
@media (max-width: 768px) {
  .card { padding: 18px; }
}
```
